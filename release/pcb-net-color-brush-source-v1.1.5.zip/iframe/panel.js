(() => {
  // src/core.mjs
  var CONFIG_KEY = "pcb-net-color-brush.v1";
  var STATUS_KEY = "pcb-net-color-brush.status.v1";
  var CAPTURE_KEY = "pcb-net-color-brush.capture.v1";
  var documentKey = (doc) => doc?.documentType === 3 && doc.uuid && doc.tabId ? JSON.stringify([doc.parentProjectUuid || "", doc.uuid, doc.tabId]) : "";
  function normalizeRules(input) {
    if (!Array.isArray(input)) throw new Error("\u914D\u8272\u89C4\u5219\u5FC5\u987B\u662F\u5217\u8868\u3002");
    const rules = /* @__PURE__ */ new Map();
    for (const rule of input) {
      if (!rule || typeof rule.net !== "string" || !rule.net.trim() || rule.color !== null && !/^#[\da-f]{6}$/i.test(rule.color) || rule.alpha !== void 0 && (!Number.isFinite(rule.alpha) || rule.alpha < 0 || rule.alpha > 1)) {
        throw new Error("\u914D\u8272\u89C4\u5219\u5305\u542B\u65E0\u6548\u7F51\u7EDC\u540D\u6216\u989C\u8272\u3002");
      }
      rules.set(rule.net, {
        net: rule.net,
        color: rule.color === null ? null : rule.color.toUpperCase(),
        ...rule.color !== null && rule.alpha !== void 0 && rule.alpha !== 1 ? { alpha: rule.alpha } : {}
      });
    }
    return [...rules.values()];
  }
  function normalizeConfig(raw) {
    if (raw == null || raw.version === 1) {
      if (raw != null && !Array.isArray(raw.rules)) throw new Error("\u65E7\u7248\u914D\u8272\u89C4\u5219\u683C\u5F0F\u65E0\u6548\uFF0C\u8BF7\u5148\u5907\u4EFD\uFF0C\u52FF\u8986\u76D6\u914D\u7F6E\u3002");
      const rules = normalizeRules(raw?.rules ?? []);
      return { version: 2, enabled: raw?.enabled !== false, profiles: [{ id: "default", name: "\u9ED8\u8BA4\u914D\u7F6E", rules }], activeProfileId: "default", rules, request: raw?.request || null };
    }
    if (raw.version !== 2 || !Array.isArray(raw.profiles) || !raw.profiles.length) throw new Error("\u5DF2\u4FDD\u5B58\u914D\u8272\u683C\u5F0F\u65E0\u6CD5\u8BC6\u522B\uFF1B\u8BF7\u5148\u5BFC\u51FA\u5907\u4EFD\uFF0C\u52FF\u8986\u76D6\u914D\u7F6E\u3002");
    const ids = /* @__PURE__ */ new Set();
    const names = /* @__PURE__ */ new Set();
    const profiles = raw.profiles.map((profile) => {
      if (!profile || typeof profile.id !== "string" || !profile.id || typeof profile.name !== "string" || !profile.name.trim() || profile.name.trim().length > 60 || ids.has(profile.id) || names.has(profile.name.trim())) throw new Error("\u914D\u7F6E\u540D\u79F0\u6216 ID \u65E0\u6548\u3001\u91CD\u590D\u3002");
      ids.add(profile.id);
      names.add(profile.name.trim());
      return { id: profile.id, name: profile.name.trim(), rules: normalizeRules(profile.rules) };
    });
    const active = profiles.find((profile) => profile.id === raw.activeProfileId);
    if (!active) throw new Error("\u5F53\u524D\u914D\u7F6E\u4E0D\u5B58\u5728\uFF0C\u8BF7\u68C0\u67E5\u5907\u4EFD\u3002");
    return { version: 2, enabled: raw.enabled !== false, profiles, activeProfileId: active.id, rules: active.rules.map((rule) => ({ ...rule })), request: raw.request || null };
  }
  function switchProfile(config2, id) {
    return normalizeConfig({ ...config2, activeProfileId: id, request: null });
  }
  function saveProfile(config2, name, rules, overwrite = false) {
    const next = normalizeConfig(config2);
    name = name.trim();
    if (!name || name.length > 60) throw new Error("\u8BF7\u8F93\u5165 1\uFF5E60 \u4E2A\u5B57\u7B26\u7684\u914D\u7F6E\u540D\u79F0\u3002");
    let profile = next.profiles.find((item) => item.name === name);
    if (profile && !overwrite) throw new Error("\u540C\u540D\u914D\u7F6E\u5DF2\u5B58\u5728\uFF1B\u8BF7\u6539\u540D\u6216\u52FE\u9009\u201C\u5141\u8BB8\u8986\u76D6\u540C\u540D\u914D\u7F6E\u201D\u3002");
    if (!profile) {
      profile = { id: `profile-${Date.now()}-${Math.random().toString(36).slice(2)}`, name, rules: [] };
      next.profiles.push(profile);
    }
    profile.rules = normalizeRules(rules);
    return switchProfile(next, profile.id);
  }
  function deleteProfile(config2, id) {
    const next = normalizeConfig(config2);
    if (!next.profiles.some((profile) => profile.id === id)) throw new Error("\u914D\u7F6E\u4E0D\u5B58\u5728\u3002");
    next.profiles = next.profiles.filter((profile) => profile.id !== id);
    if (!next.profiles.length) next.profiles = [{ id: "default", name: "\u9ED8\u8BA4\u914D\u7F6E", rules: [] }];
    if (next.activeProfileId === id) {
      next.activeProfileId = next.profiles[0].id;
      next.enabled = false;
    }
    next.request = null;
    return normalizeConfig(next);
  }
  var readConfig = (api) => normalizeConfig(api.sys_Storage.getExtensionUserConfig(CONFIG_KEY));
  async function writeConfig(api, config2) {
    const candidate = config2.version === 2 ? { ...config2, profiles: config2.profiles.map((profile) => profile.id === config2.activeProfileId ? { ...profile, rules: config2.rules } : profile) } : config2;
    const normalized = normalizeConfig(candidate);
    const legacy = api.sys_Storage.getExtensionUserConfig(CONFIG_KEY);
    if (legacy?.version === 1 && api.sys_Storage.getExtensionUserConfig(`${CONFIG_KEY}.legacy-backup`) == null) {
      if (await api.sys_Storage.setExtensionUserConfig(`${CONFIG_KEY}.legacy-backup`, legacy) !== true) throw new Error("\u65E7\u7248\u914D\u8272\u5907\u4EFD\u5931\u8D25\uFF0C\u672A\u8986\u76D6\u914D\u7F6E\u3002");
    }
    if (await api.sys_Storage.setExtensionUserConfig(CONFIG_KEY, normalized) !== true) {
      throw new Error("\u914D\u8272\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u6269\u5C55\u5B58\u50A8\u540E\u91CD\u8BD5\u3002");
    }
    if (JSON.stringify(readConfig(api)) !== JSON.stringify(normalized)) throw new Error("\u914D\u8272\u4FDD\u5B58\u540E\u6821\u9A8C\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u6216\u5BFC\u51FA\u5907\u4EFD\u3002");
    return normalized;
  }
  function rulesFromNets(nets) {
    if (!Array.isArray(nets)) throw new Error("\u65E0\u6CD5\u8BFB\u53D6 PCB \u7F51\u7EDC\u5217\u8868\u3002");
    return normalizeRules(nets.filter((item) => typeof item.net === "string" && item.net.trim()).map((item) => {
      if (item.color === null) return { net: item.net, color: null };
      const c = item.color;
      if (!c || ![c.r, c.g, c.b].every((v) => Number.isFinite(v) && v >= 0 && v <= 1) || !Number.isFinite(c.alpha) || c.alpha < 0 || c.alpha > 1) throw new Error(`\u7F51\u7EDC ${item.net} \u7684\u989C\u8272\u683C\u5F0F\u65E0\u6CD5\u8BFB\u53D6\uFF0C\u672A\u4FDD\u5B58\u914D\u7F6E\u3002`);
      if (c.r === 0 && c.g === 0 && c.b === 0 && c.alpha === 1) return { net: item.net, color: null };
      return { net: item.net, color: "#" + [c.r, c.g, c.b].map((v) => Math.round(v * 255).toString(16).padStart(2, "0")).join(""), alpha: c.alpha };
    }));
  }
  async function captureBoardRules(api) {
    const key2 = documentKey(await api.dmt_SelectControl.getCurrentDocumentInfo());
    if (!key2) throw new Error("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A PCB\u3002");
    const token = `${Date.now()}-${Math.random()}`;
    if (await api.sys_Storage.setExtensionUserConfig(CAPTURE_KEY, { token, expiresAt: Date.now() + 15e3 }) !== true) throw new Error("\u65E0\u6CD5\u6682\u505C\u540E\u53F0\u5237\u8272\uFF0C\u672A\u8BFB\u53D6\u5FEB\u7167\u3002");
    try {
      const first = rulesFromNets(await api.pcb_Net.getAllNets());
      const second = rulesFromNets(await api.pcb_Net.getAllNets());
      if (documentKey(await api.dmt_SelectControl.getCurrentDocumentInfo()) !== key2) throw new Error("\u8BFB\u53D6\u671F\u95F4 PCB \u5DF2\u5207\u6362\uFF0C\u672A\u4FDD\u5B58\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      const sorted = (rules) => JSON.stringify([...rules].sort((a, b) => a.net.localeCompare(b.net)));
      if (sorted(first) !== sorted(second)) throw new Error("\u8BFB\u53D6\u671F\u95F4\u7F51\u7EDC\u989C\u8272\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u8BD5\u3002");
      if (!second.length) throw new Error("\u5F53\u524D PCB \u6CA1\u6709\u53EF\u4FDD\u5B58\u7684\u7F51\u7EDC\u3002");
      return second;
    } finally {
      if (api.sys_Storage.getExtensionUserConfig(CAPTURE_KEY)?.token === token) await api.sys_Storage.setExtensionUserConfig(CAPTURE_KEY, null);
    }
  }
  function selectedNets(items) {
    return [...new Set((Array.isArray(items) ? items : []).map((item) => {
      if (item?.primitiveType === "Component" || item?.getState_PrimitiveType?.() === "Component") return "";
      return item?.net ?? item?.getState_Net?.();
    }).filter((net) => typeof net === "string" && net.trim()))];
  }

  // src/filter.mjs
  function createFilterSession(host) {
    let saved = [];
    const targets = { Pad: true, Via: true, Track: true, "Copper Region": true, Component: false };
    function control(title) {
      const panel = host?.getElementById("pcb-filter");
      const labels = panel ? [...panel.querySelectorAll("label[data-test]")] : [];
      const label = labels.find((node) => node.getAttribute("data-test") === title);
      const input = label && host.getElementById(label.htmlFor);
      if (!input || input.type !== "checkbox" || input.disabled || !panel.contains(input)) throw new Error("\u65E0\u6CD5\u8BBF\u95EE PCB \u8FC7\u6EE4\u9879\uFF1A" + title);
      return input;
    }
    function restore() {
      host?.removeEventListener("pointerdown", onHostInteraction, true);
      const failed = [];
      for (const item of [...saved].reverse()) {
        try {
          const input = control(item.title);
          if (input.checked !== item.before) input.click();
          if (control(item.title).checked !== item.before) throw new Error("\u6062\u590D\u5931\u8D25");
        } catch {
          failed.push(item);
        }
      }
      saved = failed.reverse();
      return saved.length === 0;
    }
    function onHostInteraction() {
      restore();
    }
    function enable() {
      if (!restore()) throw new Error("\u4E0A\u6B21\u8FC7\u6EE4\u8BBE\u7F6E\u672A\u6062\u590D\uFF0C\u8BF7\u68C0\u67E5\u8FC7\u6EE4\u9762\u677F\u3002");
      const before = Object.entries(targets).map(([title, wanted]) => ({ title, wanted, before: control(title).checked }));
      try {
        for (const item of before) {
          if (item.before === item.wanted) continue;
          saved.push(item);
          control(item.title).click();
          if (control(item.title).checked !== item.wanted) throw new Error("\u8FC7\u6EE4\u9879\u672A\u751F\u6548\uFF1A" + item.title);
        }
        host.addEventListener("pointerdown", onHostInteraction, true);
        return true;
      } catch (error) {
        restore();
        throw error;
      }
    }
    return { enable, restore, get active() {
      return saved.length > 0;
    } };
  }

  // src/panel.js
  var $ = (id) => document.getElementById(id);
  var LISTENER = "pcb-net-color-brush-picker";
  var config;
  var key = "";
  var disposed = false;
  var busy = false;
  var picking = true;
  var pending = null;
  var refreshing = false;
  var selectionEpoch = 0;
  var filterSession;
  function enableCanvasPick() {
    picking = true;
    try {
      if (!filterSession) filterSession = createFilterSession(window.frameElement?.ownerDocument);
      filterSession.enable();
      message("\u8BF7\u70B9\u9009\u710A\u76D8\u3001\u8FC7\u5B54\u3001\u5BFC\u7EBF\u6216\u94FA\u94DC\u3002\u5173\u95ED\u7A97\u53E3\u6062\u590D\u8FC7\u6EE4\u3002");
    } catch (error) {
      message(`\u81EA\u52A8\u8FC7\u6EE4\u4E0D\u53EF\u7528\uFF1A${error.message}\u3002\u8BF7\u5728\u8FC7\u6EE4\u9762\u677F\u624B\u52A8\u52FE\u9009\u76F8\u5173\u56FE\u5143\u3002`, true);
    }
  }
  var message = (text, error = false) => {
    $("message").textContent = text;
    $("message").className = error ? "error" : "";
  };
  var fail = (error) => message(String(error.message || error), true);
  function updatePreview() {
    $("color").style.backgroundColor = $("hex").value;
    $("color").textContent = $("default-color").checked ? "\u9ED8\u8BA4" : "";
  }
  function selectColor(hex) {
    $("hex").value = hex;
    $("default-color").checked = false;
    updatePreview();
    $("palette-panel").hidden = true;
  }
  function initPalette() {
    const hex = (values) => "#" + values.map((v) => Math.round(v).toString(16).padStart(2, "0")).join("").toUpperCase();
    const colors = Array.from({ length: 24 }, (_, i) => hex([i * 255 / 23, i * 255 / 23, i * 255 / 23]));
    for (const [s, v] of [[1, 0.25], [1, 0.4], [1, 0.55], [1, 0.7], [1, 0.85], [1, 1], [0.75, 1], [0.5, 1], [0.25, 1]]) {
      for (let h = 0; h < 24; h++) {
        const hue = h / 4;
        const c = v * s;
        const x = c * (1 - Math.abs(hue % 2 - 1));
        const m = v - c;
        const channels = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][Math.floor(hue)];
        colors.push(hex(channels.map((n) => (n + m) * 255)));
      }
    }
    for (const color of colors) {
      const swatch = document.createElement("button");
      swatch.className = "swatch";
      swatch.style.backgroundColor = color;
      swatch.title = color;
      swatch.textContent = color;
      swatch.onclick = () => selectColor(color);
      $("palette-grid").append(swatch);
    }
    $("color").onclick = () => {
      $("palette-panel").hidden = !$("palette-panel").hidden;
    };
    $("palette-close").onclick = () => {
      $("palette-panel").hidden = true;
    };
    $("palette-default").onclick = () => {
      $("default-color").checked = true;
      updatePreview();
      $("palette-panel").hidden = true;
    };
    $("default-color").onchange = updatePreview;
    updatePreview();
  }
  function colorForNet() {
    const rule = config.rules.find((rule2) => rule2.net === $("net").value);
    $("default-color").checked = rule?.color === null;
    $("alpha").value = rule?.alpha ?? 1;
    if (rule?.color) {
      $("hex").value = rule.color;
      $("color").value = rule.color;
    }
    updatePreview();
  }
  function choose(net) {
    $("net").value = net;
    colorForNet();
    message(`\u5DF2\u9009\u62E9\u7F51\u7EDC\uFF1A${net}\u3002\u9009\u62E9\u989C\u8272\u540E\u70B9\u51FB\u201C\u4FDD\u5B58\u914D\u8272\u5E76\u5E94\u7528\u201D\u3002`);
  }
  function render() {
    $("enabled").checked = config.enabled;
    $("profiles").replaceChildren();
    for (const profile of config.profiles) {
      const option = document.createElement("option");
      option.value = profile.id;
      option.textContent = `${profile.name}\uFF08${profile.rules.length} \u4E2A\u7F51\u7EDC\uFF09`;
      $("profiles").append(option);
    }
    $("profiles").value = config.activeProfileId;
    $("active-profile").textContent = config.profiles.find((item) => item.id === config.activeProfileId).name;
    $("rules").replaceChildren();
    if (!config.rules.length) {
      $("rules").textContent = "\u8FD8\u6CA1\u6709\u89C4\u5219\uFF0C\u5148\u9009\u62E9\u4E00\u4E2A\u7F51\u7EDC\u5E76\u4FDD\u5B58\u989C\u8272\u3002";
      return;
    }
    for (const rule of config.rules) {
      const row = document.createElement("div");
      row.className = "rule";
      const dot = document.createElement("span");
      dot.className = "dot";
      dot.style.backgroundColor = rule.color || "transparent";
      dot.style.opacity = rule.alpha ?? 1;
      const net = document.createElement("span");
      net.className = "net";
      net.textContent = `${rule.net}  ${rule.color || "EDA \u9ED8\u8BA4\u989C\u8272"}${rule.alpha !== void 0 ? ` / \u4E0D\u900F\u660E\u5EA6 ${rule.alpha}` : ""}`;
      const edit = document.createElement("button");
      edit.textContent = "\u7F16\u8F91";
      edit.onclick = () => choose(rule.net);
      const remove = document.createElement("button");
      remove.textContent = "\u5220\u9664";
      remove.onclick = () => run(async () => {
        const next = readConfig(eda);
        next.rules = next.rules.filter((item) => item.net !== rule.net);
        next.request = null;
        config = await writeConfig(eda, next);
        render();
        message(`\u5DF2\u5220\u9664 ${rule.net} \u7684\u81EA\u52A8\u914D\u8272\u89C4\u5219\uFF1B\u73B0\u6709 PCB \u989C\u8272\u4FDD\u7559\u3002`);
      });
      row.append(dot, net, edit, remove);
      $("rules").append(row);
    }
  }
  async function run(fn) {
    if (busy) return;
    busy = true;
    document.querySelectorAll("button, input, select, textarea").forEach((button) => {
      button.disabled = true;
    });
    try {
      await fn();
    } catch (error) {
      fail(error);
    } finally {
      busy = false;
      document.querySelectorAll("button, input, select, textarea").forEach((button) => {
        button.disabled = false;
      });
    }
  }
  async function requestApply(next) {
    const current = documentKey(await eda.dmt_SelectControl.getCurrentDocumentInfo());
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    next.request = current ? { id, documentKey: current } : null;
    config = await writeConfig(eda, next);
    pending = current ? { id, at: Date.now(), documentKey: current } : null;
    render();
    message(current ? "\u914D\u8272\u5DF2\u4FDD\u5B58\uFF0C\u6B63\u5728\u5957\u7528\u5F53\u524D PCB\u2026" : "\u914D\u8272\u5DF2\u4FDD\u5B58\uFF1B\u6253\u5F00 PCB \u540E\u81EA\u52A8\u5957\u7528\u540C\u540D\u7F51\u7EDC\u3002");
  }
  async function refreshNets() {
    const current = documentKey(await eda.dmt_SelectControl.getCurrentDocumentInfo());
    key = current;
    $("net-list").replaceChildren();
    if (!current) return;
    const nets = await eda.pcb_Net.getAllNets();
    if (documentKey(await eda.dmt_SelectControl.getCurrentDocumentInfo()) !== current) return;
    for (const net of nets) {
      if (!net.net) continue;
      const option = document.createElement("option");
      option.value = net.net;
      $("net-list").append(option);
    }
  }
  async function pick(event, props) {
    if (event !== "selected" || !picking || busy || disposed) return;
    const epoch = ++selectionEpoch;
    const current = documentKey(await eda.dmt_SelectControl.getCurrentDocumentInfo());
    if (!current) return;
    let nets = selectedNets(props);
    if (!nets.length) nets = selectedNets(await eda.pcb_SelectControl.getAllSelectedPrimitives());
    if (disposed || epoch !== selectionEpoch || documentKey(await eda.dmt_SelectControl.getCurrentDocumentInfo()) !== current) return;
    key = current;
    $("choices").replaceChildren();
    $("choices").hidden = nets.length < 2;
    if (!nets.length) {
      message("\u6240\u9009\u56FE\u5143\u6CA1\u6709\u7F51\u7EDC\u3002\u8BF7\u76F4\u63A5\u70B9\u51FB\u710A\u76D8\u3001\u8D70\u7EBF\u6216\u8FC7\u5B54\u3002");
      return;
    }
    if (nets.length === 1) {
      choose(nets[0]);
      return;
    }
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "\u9009\u4E2D\u4E86\u591A\u4E2A\u7F51\u7EDC\uFF0C\u8BF7\u9009\u62E9\u4E00\u4E2A";
    $("choices").append(placeholder);
    for (const net of nets) {
      const option = document.createElement("option");
      option.value = net;
      option.textContent = net;
      $("choices").append(option);
    }
    $("net").value = "";
    message("\u9009\u4E2D\u4E86\u591A\u4E2A\u7F51\u7EDC\uFF0C\u8BF7\u5728\u4E0B\u62C9\u6846\u4E2D\u6307\u5B9A\u8981\u5237\u8272\u7684\u7F51\u7EDC\u3002");
  }
  async function poll() {
    if (refreshing || disposed || busy) return;
    refreshing = true;
    try {
      const current = documentKey(await eda.dmt_SelectControl.getCurrentDocumentInfo());
      if (current !== key) {
        selectionEpoch += 1;
        $("net").value = "";
        $("choices").hidden = true;
        await refreshNets();
        message("\u6587\u6863\u5DF2\u5207\u6362\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u7F51\u7EDC\uFF1B\u81EA\u52A8\u914D\u8272\u5C06\u5957\u7528\u5DF2\u4FDD\u5B58\u89C4\u5219\u3002");
      }
      if (pending) {
        const status = eda.sys_Storage.getExtensionUserConfig(STATUS_KEY);
        if (status?.id === pending.id) {
          message(status.errors?.length ? `\u914D\u8272\u5DF2\u4FDD\u5B58\uFF0C\u4F46\u90E8\u5206\u7F51\u7EDC\u8BBE\u7F6E\u5931\u8D25\uFF1A
${status.errors.join("\n")}` : `\u5DF2\u5957\u7528\u914D\u8272\uFF0C\u66F4\u65B0 ${status.changed} \u4E2A\u7F51\u7EDC\u3002\u4E0D\u5B58\u5728\u7684\u7F51\u7EDC\u89C4\u5219\u4F1A\u4FDD\u7559\u4F9B\u540E\u7EED PCB \u4F7F\u7528\u3002`, !!status.errors?.length);
          pending = null;
        } else if (Date.now() - pending.at > 1e4) {
          message("\u89C4\u5219\u5DF2\u4FDD\u5B58\uFF0C\u5C1A\u672A\u6536\u5230\u5E94\u7528\u7ED3\u679C\u3002\u8BF7\u56DE\u5230\u76EE\u6807 PCB\uFF0C\u6216\u4F7F\u7528\u9876\u90E8\u83DC\u5355\u201C\u7ACB\u5373\u5957\u7528\u5DF2\u4FDD\u5B58\u914D\u8272\u201D\uFF1B\u5982\u4ECD\u65E0\u54CD\u5E94\uFF0C\u8BF7\u91CD\u65B0\u542F\u7528\u6269\u5C55\u3002", true);
          pending = null;
        }
      }
    } catch (error) {
      fail(error);
    } finally {
      refreshing = false;
    }
  }
  async function start() {
    config = readConfig(eda);
    render();
    initPalette();
    $("profile-delete").onclick = () => {
      const selected = readConfig(eda).profiles.find((p) => p.id === $("profiles").value);
      if (!selected) return;
      $("delete-label").textContent = `\u5220\u9664\u201C${selected.name}\u201D\uFF1F`;
      $("delete-confirm").hidden = false;
      $("delete-confirm").dataset.profileId = selected.id;
    };
    $("delete-cancel").onclick = () => {
      $("delete-confirm").hidden = true;
    };
    $("delete-ok").onclick = () => run(async () => {
      const next = readConfig(eda);
      const id = $("delete-confirm").dataset.profileId;
      const active = id === next.activeProfileId;
      config = await writeConfig(eda, deleteProfile(next, id));
      pending = null;
      $("delete-confirm").hidden = true;
      render();
      message(active ? "\u5DF2\u5220\u9664\uFF1B\u81EA\u52A8\u914D\u8272\u5DF2\u6682\u505C\uFF0CPCB \u989C\u8272\u4FDD\u7559\u3002" : "\u914D\u7F6E\u5DF2\u5220\u9664\uFF0CPCB \u989C\u8272\u4FDD\u7559\u3002");
    });
    $("profile-apply").onclick = () => run(() => requestApply(switchProfile(readConfig(eda), $("profiles").value)));
    $("profile-copy").onclick = () => run(async () => {
      const next = readConfig(eda);
      if (!next.rules.length) throw new Error("\u5F53\u524D\u89C4\u5219\u4E3A\u7A7A\u3002\u8981\u4FDD\u5B58\u753B\u5E03\u5DF2\u6709\u989C\u8272\uFF0C\u8BF7\u70B9\u51FB\u201C\u4FDD\u5B58\u5F53\u524D PCB \u989C\u8272\u201D\u3002");
      config = await writeConfig(eda, saveProfile(next, $("profile-name").value, next.rules, $("overwrite-profile").checked));
      pending = null;
      render();
      message("\u89C4\u5219\u5DF2\u53E6\u5B58\u4E3A\u5F53\u524D\u914D\u7F6E\uFF0C\u540E\u7EED PCB \u4F7F\u7528\u6B64\u914D\u7F6E\u3002");
    });
    $("profile-capture").onclick = () => run(async () => {
      const overwrite = $("overwrite-profile").checked;
      const selected = readConfig(eda).profiles.find((profile) => profile.id === $("profiles").value);
      const name = $("profile-name").value.trim() || (overwrite ? selected?.name || "" : "");
      saveProfile(readConfig(eda), name, [], overwrite);
      message("\u6B63\u5728\u8BFB\u53D6\u5E76\u4FDD\u5B58\u5F53\u524D PCB \u7684\u7F51\u7EDC\u989C\u8272\u2026");
      const rules = await captureBoardRules(eda);
      config = await writeConfig(eda, saveProfile(readConfig(eda), name, rules, overwrite));
      pending = null;
      render();
      message(`\u5DF2\u5C06\u5F53\u524D PCB \u7684 ${rules.length} \u4E2A\u7F51\u7EDC\u989C\u8272\u4FDD\u5B58\u4E3A\u201C${name}\u201D\uFF0C\u5E76\u8BBE\u4E3A\u5F53\u524D\u914D\u7F6E\u3002\u672A\u4FEE\u6539 PCB\u3002`);
    });
    $("color").oninput = () => {
      $("hex").value = $("color").value.toUpperCase();
    };
    $("hex").oninput = () => {
      if (/^#[\da-f]{6}$/i.test($("hex").value)) {
        $("default-color").checked = false;
        updatePreview();
      }
    };
    $("net").onchange = colorForNet;
    $("choices").onchange = () => {
      if ($("choices").value) choose($("choices").value);
    };
    $("pick").onclick = enableCanvasPick;
    $("net").onfocus = () => {
      picking = false;
      filterSession?.restore();
    };
    $("refresh").onclick = () => run(async () => {
      await refreshNets();
      message("\u5DF2\u5237\u65B0\u5F53\u524D PCB \u7F51\u7EDC\u5217\u8868\u3002");
    });
    $("save").onclick = () => run(async () => {
      const net = $("net").value;
      const color = $("hex").value.trim().toUpperCase();
      if (!net.trim()) throw new Error("\u8BF7\u5148\u9009\u62E9\u6216\u8F93\u5165\u7F51\u7EDC\u540D\u3002");
      const useDefault = $("default-color").checked;
      const alpha = Number($("alpha").value);
      if (!useDefault && (!/^#[\da-f]{6}$/i.test(color) || !Number.isFinite(alpha) || alpha < 0 || alpha > 1)) throw new Error("\u989C\u8272\u5FC5\u987B\u662F #RRGGBB\uFF0C\u4E0D\u900F\u660E\u5EA6\u4E3A 0\uFF5E1\u3002");
      const next = readConfig(eda);
      next.rules = next.rules.filter((rule) => rule.net !== net);
      next.rules.push({ net, color: useDefault ? null : color, ...!useDefault && alpha !== 1 ? { alpha } : {} });
      await requestApply(next);
      picking = true;
    });
    $("apply").onclick = () => run(() => requestApply(readConfig(eda)));
    $("enabled").onchange = () => run(async () => {
      const next = readConfig(eda);
      next.enabled = $("enabled").checked;
      next.request = null;
      try {
        config = await writeConfig(eda, next);
      } finally {
        config = readConfig(eda);
        render();
      }
      message(config.enabled ? "\u81EA\u52A8\u914D\u8272\u5DF2\u5F00\u542F\uFF0C\u5173\u95ED\u7A97\u53E3\u540E\u4ECD\u751F\u6548\u3002" : "\u81EA\u52A8\u914D\u8272\u5DF2\u6682\u505C\uFF1B\u4FDD\u5B58\u6216\u624B\u52A8\u5957\u7528\u4ECD\u53EF\u7ED9\u5F53\u524D PCB \u5237\u8272\u3002");
    });
    $("export").onclick = () => {
      const next = readConfig(eda);
      delete next.request;
      $("backup").value = JSON.stringify(next, null, 2);
      message("\u5DF2\u5BFC\u51FA\uFF0C\u8BF7\u590D\u5236\u6587\u672C\u4FDD\u5B58\u3002");
    };
    $("import").onclick = () => run(async () => {
      const incoming = normalizeConfig(JSON.parse($("backup").value));
      let next = readConfig(eda);
      const active = next.activeProfileId;
      for (const profile of incoming.profiles) {
        const existing = next.profiles.find((item) => item.name === profile.name);
        const rules = new Map((existing?.rules || []).map((rule) => [rule.net, rule]));
        for (const rule of profile.rules) rules.set(rule.net, rule);
        next = saveProfile(next, profile.name, [...rules.values()], true);
      }
      await requestApply(switchProfile(next, active));
    });
    await refreshNets();
    try {
      eda.pcb_Event.removeEventListener(LISTENER);
      eda.pcb_Event.addMouseEventListener(LISTENER, "all", (event, props) => {
        void pick(event, props).catch(fail);
      }, false);
      if (!eda.pcb_Event.isEventListenerAlreadyExist(LISTENER)) throw new Error("\u753B\u5E03\u76D1\u542C\u6CE8\u518C\u5931\u8D25");
      enableCanvasPick();
    } catch (error) {
      message(`\u753B\u5E03\u9009\u53D6\u6682\u4E0D\u53EF\u7528\uFF1A${error.message}\u3002\u4ECD\u53EF\u8F93\u5165\u7F51\u7EDC\u540D\u8BBE\u7F6E\u914D\u8272\u3002`, true);
    }
  }
  var timer = setInterval(() => {
    void poll();
  }, 1e3);
  function dispose() {
    filterSession?.restore();
    disposed = true;
    selectionEpoch += 1;
    clearInterval(timer);
    try {
      eda.pcb_Event.removeEventListener(LISTENER);
    } catch {
    }
  }
  window.addEventListener("pagehide", dispose);
  window.addEventListener("beforeunload", dispose);
  void start().catch(fail);
})();
